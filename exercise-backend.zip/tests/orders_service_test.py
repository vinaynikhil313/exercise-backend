from orders_service import create_and_place_order


def test_create_and_place_order_success(mocker):
    mocker.patch("app.")
